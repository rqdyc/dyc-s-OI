#include <bits/stdc++.h>
using namespace std;
#define ll long long
ll a, b;
int main()
{
    cin >> a >> b;
    cout << a + b << endl;
}